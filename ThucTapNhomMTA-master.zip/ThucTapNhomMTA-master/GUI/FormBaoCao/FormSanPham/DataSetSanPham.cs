﻿namespace GUI.FormBaoCao.FormSanPham
{


    partial class DataSetSanPham
    {
        partial class DataTable1DataTable
        {
        }
    }
}
