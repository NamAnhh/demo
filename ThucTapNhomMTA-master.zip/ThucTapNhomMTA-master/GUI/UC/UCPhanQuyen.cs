﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI.UC
{
    public partial class UCPhanQuyen : UserControl
    {
        public UCPhanQuyen()
        {
            InitializeComponent();
        }
    }
}
