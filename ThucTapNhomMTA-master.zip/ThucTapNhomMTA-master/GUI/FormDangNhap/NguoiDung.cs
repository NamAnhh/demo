﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GUI.FormDangNhap
{
    public static class NguoiDung
    {
        public static string TenNguoiDung
        {
            get;
            set; 
        }
        public static string TaiKhoan
        {
            get;
            set;
        }
    }
}
