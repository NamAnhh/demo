﻿namespace GUI
{
    partial class frmQuanLyBanHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmQuanLyBanHang));
            this.ribbonControl1 = new DevComponents.DotNetBar.RibbonControl();
            this.ribbonPanel2 = new DevComponents.DotNetBar.RibbonPanel();
            this.rbbKhoHang = new DevComponents.DotNetBar.RibbonBar();
            this.btbKhoHang = new DevComponents.DotNetBar.ButtonItem();
            this.rbbLoaiSanPham = new DevComponents.DotNetBar.RibbonBar();
            this.btnLoaiSanPham = new DevComponents.DotNetBar.ButtonItem();
            this.rbbSanPham = new DevComponents.DotNetBar.RibbonBar();
            this.btnSanPham = new DevComponents.DotNetBar.ButtonItem();
            this.rbbLoaiKhachHang = new DevComponents.DotNetBar.RibbonBar();
            this.btnloaiKhachHang = new DevComponents.DotNetBar.ButtonItem();
            this.rbbKhachHang = new DevComponents.DotNetBar.RibbonBar();
            this.btnKhachHang = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar2 = new DevComponents.DotNetBar.RibbonBar();
            this.btnNhanVien = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar4 = new DevComponents.DotNetBar.RibbonBar();
            this.btnNhaCungCap = new DevComponents.DotNetBar.ButtonItem();
            this.rbbNhaSanXuat = new DevComponents.DotNetBar.RibbonBar();
            this.btnNhaSanSuat = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel3 = new DevComponents.DotNetBar.RibbonPanel();
            this.rbbHoaDonBan = new DevComponents.DotNetBar.RibbonBar();
            this.btnHoaDonBan = new DevComponents.DotNetBar.ButtonItem();
            this.rbbHoaDonNhapHang = new DevComponents.DotNetBar.RibbonBar();
            this.btnHoaDonNhap = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel4 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar5 = new DevComponents.DotNetBar.RibbonBar();
            this.btnLienHe = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar6 = new DevComponents.DotNetBar.RibbonBar();
            this.btnHoiDap = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel1 = new DevComponents.DotNetBar.RibbonPanel();
            this.rbbThoatHeThong = new DevComponents.DotNetBar.RibbonBar();
            this.btnThoatHeThong = new DevComponents.DotNetBar.ButtonItem();
            this.rbbDoiHinhNen = new DevComponents.DotNetBar.RibbonBar();
            this.btnDoiHinhNen = new DevComponents.DotNetBar.ButtonItem();
            this.rbbNguoiDung = new DevComponents.DotNetBar.RibbonBar();
            this.btnNguoiDung = new DevComponents.DotNetBar.ButtonItem();
            this.rbbPhamQuyen = new DevComponents.DotNetBar.RibbonBar();
            this.btnPhanQuyen = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel5 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar7 = new DevComponents.DotNetBar.RibbonBar();
            this.btnThongTinCaNhan = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar8 = new DevComponents.DotNetBar.RibbonBar();
            this.btnDangXuat = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel6 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar10 = new DevComponents.DotNetBar.RibbonBar();
            this.btnDoiTac = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar11 = new DevComponents.DotNetBar.RibbonBar();
            this.btnNhaPhatTrien = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar12 = new DevComponents.DotNetBar.RibbonBar();
            this.btnThongtinNPT = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonTabItem1 = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribbonTabItem2 = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribbonTabItem3 = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribbonTabItem4 = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribbonTabItem5 = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribbonTabItem6 = new DevComponents.DotNetBar.RibbonTabItem();
            this.textBoxItem1 = new DevComponents.DotNetBar.TextBoxItem();
            this.styleManager1 = new DevComponents.DotNetBar.StyleManager(this.components);
            this.TabHeThong = new DevComponents.DotNetBar.TabControl();
            this.tabControlPanel1 = new DevComponents.DotNetBar.TabControlPanel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.TabGioiThieu = new DevComponents.DotNetBar.TabItem(this.components);
            this.rbTabQuanLy = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribbonTabItem7 = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribbonTabItem8 = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribbonTabItem9 = new DevComponents.DotNetBar.RibbonTabItem();
            this.MenuStripHeThong = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.MenuItemDongTrang = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemDongTrangKhac = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemDongTatCa = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.MenuItemThoat = new System.Windows.Forms.ToolStripMenuItem();
            this.ribbonControl1.SuspendLayout();
            this.ribbonPanel2.SuspendLayout();
            this.ribbonPanel3.SuspendLayout();
            this.ribbonPanel4.SuspendLayout();
            this.ribbonPanel1.SuspendLayout();
            this.ribbonPanel5.SuspendLayout();
            this.ribbonPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TabHeThong)).BeginInit();
            this.TabHeThong.SuspendLayout();
            this.tabControlPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.MenuStripHeThong.SuspendLayout();
            this.SuspendLayout();
            // 
            // ribbonControl1
            // 
            // 
            // 
            // 
            this.ribbonControl1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonControl1.CaptionVisible = true;
            this.ribbonControl1.Controls.Add(this.ribbonPanel3);
            this.ribbonControl1.Controls.Add(this.ribbonPanel2);
            this.ribbonControl1.Controls.Add(this.ribbonPanel4);
            this.ribbonControl1.Controls.Add(this.ribbonPanel1);
            this.ribbonControl1.Controls.Add(this.ribbonPanel5);
            this.ribbonControl1.Controls.Add(this.ribbonPanel6);
            this.ribbonControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.ribbonControl1.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.ribbonTabItem1,
            this.ribbonTabItem2,
            this.ribbonTabItem3,
            this.ribbonTabItem4,
            this.ribbonTabItem5,
            this.ribbonTabItem6});
            this.ribbonControl1.KeyTipsFont = new System.Drawing.Font("Tahoma", 7F);
            this.ribbonControl1.Location = new System.Drawing.Point(5, 1);
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.Padding = new System.Windows.Forms.Padding(0, 0, 0, 3);
            this.ribbonControl1.Size = new System.Drawing.Size(790, 154);
            this.ribbonControl1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonControl1.SystemText.MaximizeRibbonText = "&Maximize the Ribbon";
            this.ribbonControl1.SystemText.MinimizeRibbonText = "Mi&nimize the Ribbon";
            this.ribbonControl1.SystemText.QatAddItemText = "&Add to Quick Access Toolbar";
            this.ribbonControl1.SystemText.QatCustomizeMenuLabel = "<b>Customize Quick Access Toolbar</b>";
            this.ribbonControl1.SystemText.QatCustomizeText = "&Customize Quick Access Toolbar...";
            this.ribbonControl1.SystemText.QatDialogAddButton = "&Add >>";
            this.ribbonControl1.SystemText.QatDialogCancelButton = "Cancel";
            this.ribbonControl1.SystemText.QatDialogCaption = "Customize Quick Access Toolbar";
            this.ribbonControl1.SystemText.QatDialogCategoriesLabel = "&Choose commands from:";
            this.ribbonControl1.SystemText.QatDialogOkButton = "OK";
            this.ribbonControl1.SystemText.QatDialogPlacementCheckbox = "&Place Quick Access Toolbar below the Ribbon";
            this.ribbonControl1.SystemText.QatDialogRemoveButton = "&Remove";
            this.ribbonControl1.SystemText.QatPlaceAboveRibbonText = "&Place Quick Access Toolbar above the Ribbon";
            this.ribbonControl1.SystemText.QatPlaceBelowRibbonText = "&Place Quick Access Toolbar below the Ribbon";
            this.ribbonControl1.SystemText.QatRemoveItemText = "&Remove from Quick Access Toolbar";
            this.ribbonControl1.TabGroupHeight = 14;
            this.ribbonControl1.TabIndex = 0;
            this.ribbonControl1.Text = "ribbonControl1";
            this.ribbonControl1.Click += new System.EventHandler(this.ribbonControl1_Click);
            // 
            // ribbonPanel2
            // 
            this.ribbonPanel2.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonPanel2.Controls.Add(this.rbbKhoHang);
            this.ribbonPanel2.Controls.Add(this.rbbLoaiSanPham);
            this.ribbonPanel2.Controls.Add(this.rbbSanPham);
            this.ribbonPanel2.Controls.Add(this.rbbLoaiKhachHang);
            this.ribbonPanel2.Controls.Add(this.rbbKhachHang);
            this.ribbonPanel2.Controls.Add(this.ribbonBar2);
            this.ribbonPanel2.Controls.Add(this.ribbonBar4);
            this.ribbonPanel2.Controls.Add(this.rbbNhaSanXuat);
            this.ribbonPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel2.Location = new System.Drawing.Point(0, 53);
            this.ribbonPanel2.Name = "ribbonPanel2";
            this.ribbonPanel2.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel2.Size = new System.Drawing.Size(790, 98);
            // 
            // 
            // 
            this.ribbonPanel2.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel2.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel2.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonPanel2.TabIndex = 2;
            // 
            // rbbKhoHang
            // 
            this.rbbKhoHang.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.rbbKhoHang.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.rbbKhoHang.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.rbbKhoHang.ContainerControlProcessDialogKey = true;
            this.rbbKhoHang.Dock = System.Windows.Forms.DockStyle.Left;
            this.rbbKhoHang.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btbKhoHang});
            this.rbbKhoHang.Location = new System.Drawing.Point(621, 0);
            this.rbbKhoHang.Name = "rbbKhoHang";
            this.rbbKhoHang.Size = new System.Drawing.Size(88, 95);
            this.rbbKhoHang.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.rbbKhoHang.TabIndex = 27;
            this.rbbKhoHang.Text = "Kho Hang  ";
            // 
            // 
            // 
            this.rbbKhoHang.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.rbbKhoHang.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btbKhoHang
            // 
            this.btbKhoHang.Image = global::GUI.Properties.Resources.kho_hang;
            this.btbKhoHang.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btbKhoHang.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.btbKhoHang.Name = "btbKhoHang";
            this.btbKhoHang.SubItemsExpandWidth = 14;
            this.btbKhoHang.Text = "<div align = \"center\" width = \"70\"></div>";
            this.btbKhoHang.Click += new System.EventHandler(this.btbKhoHang_Click);
            // 
            // rbbLoaiSanPham
            // 
            this.rbbLoaiSanPham.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.rbbLoaiSanPham.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.rbbLoaiSanPham.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.rbbLoaiSanPham.ContainerControlProcessDialogKey = true;
            this.rbbLoaiSanPham.Dock = System.Windows.Forms.DockStyle.Left;
            this.rbbLoaiSanPham.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnLoaiSanPham});
            this.rbbLoaiSanPham.Location = new System.Drawing.Point(533, 0);
            this.rbbLoaiSanPham.Name = "rbbLoaiSanPham";
            this.rbbLoaiSanPham.Size = new System.Drawing.Size(88, 95);
            this.rbbLoaiSanPham.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.rbbLoaiSanPham.TabIndex = 26;
            this.rbbLoaiSanPham.Text = "loại Sản Phẩm ";
            // 
            // 
            // 
            this.rbbLoaiSanPham.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.rbbLoaiSanPham.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnLoaiSanPham
            // 
            this.btnLoaiSanPham.Image = global::GUI.Properties.Resources.Class;
            this.btnLoaiSanPham.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnLoaiSanPham.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.btnLoaiSanPham.Name = "btnLoaiSanPham";
            this.btnLoaiSanPham.SubItemsExpandWidth = 14;
            this.btnLoaiSanPham.Text = "<div align = \"center\" width = \"70\"></div>";
            this.btnLoaiSanPham.Click += new System.EventHandler(this.btnLoaiSanPham_Click);
            // 
            // rbbSanPham
            // 
            this.rbbSanPham.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.rbbSanPham.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.rbbSanPham.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.rbbSanPham.ContainerControlProcessDialogKey = true;
            this.rbbSanPham.Dock = System.Windows.Forms.DockStyle.Left;
            this.rbbSanPham.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnSanPham});
            this.rbbSanPham.Location = new System.Drawing.Point(445, 0);
            this.rbbSanPham.Name = "rbbSanPham";
            this.rbbSanPham.Size = new System.Drawing.Size(88, 95);
            this.rbbSanPham.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.rbbSanPham.TabIndex = 25;
            this.rbbSanPham.Text = "Sản Phẩm ";
            // 
            // 
            // 
            this.rbbSanPham.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.rbbSanPham.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnSanPham
            // 
            this.btnSanPham.Image = global::GUI.Properties.Resources.SanPham;
            this.btnSanPham.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnSanPham.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.btnSanPham.Name = "btnSanPham";
            this.btnSanPham.SubItemsExpandWidth = 14;
            this.btnSanPham.Text = "<div align = \"center\" width = \"70\"></div>";
            this.btnSanPham.Click += new System.EventHandler(this.btnSanPham_Click);
            // 
            // rbbLoaiKhachHang
            // 
            this.rbbLoaiKhachHang.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.rbbLoaiKhachHang.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.rbbLoaiKhachHang.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.rbbLoaiKhachHang.ContainerControlProcessDialogKey = true;
            this.rbbLoaiKhachHang.Dock = System.Windows.Forms.DockStyle.Left;
            this.rbbLoaiKhachHang.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnloaiKhachHang});
            this.rbbLoaiKhachHang.Location = new System.Drawing.Point(355, 0);
            this.rbbLoaiKhachHang.Name = "rbbLoaiKhachHang";
            this.rbbLoaiKhachHang.Size = new System.Drawing.Size(90, 95);
            this.rbbLoaiKhachHang.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.rbbLoaiKhachHang.TabIndex = 24;
            this.rbbLoaiKhachHang.Text = "Loại Khách Hàng ";
            // 
            // 
            // 
            this.rbbLoaiKhachHang.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.rbbLoaiKhachHang.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnloaiKhachHang
            // 
            this.btnloaiKhachHang.Image = global::GUI.Properties.Resources.GetArticleImage;
            this.btnloaiKhachHang.ImageFixedSize = new System.Drawing.Size(55, 55);
            this.btnloaiKhachHang.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.btnloaiKhachHang.Name = "btnloaiKhachHang";
            this.btnloaiKhachHang.SubItemsExpandWidth = 14;
            this.btnloaiKhachHang.Text = "<div align = \"center\" width = \"80\"></div>";
            this.btnloaiKhachHang.Click += new System.EventHandler(this.btnloaiKhachHang_Click);
            // 
            // rbbKhachHang
            // 
            this.rbbKhachHang.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.rbbKhachHang.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.rbbKhachHang.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.rbbKhachHang.ContainerControlProcessDialogKey = true;
            this.rbbKhachHang.Dock = System.Windows.Forms.DockStyle.Left;
            this.rbbKhachHang.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnKhachHang});
            this.rbbKhachHang.Location = new System.Drawing.Point(267, 0);
            this.rbbKhachHang.Name = "rbbKhachHang";
            this.rbbKhachHang.Size = new System.Drawing.Size(88, 95);
            this.rbbKhachHang.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.rbbKhachHang.TabIndex = 23;
            this.rbbKhachHang.Text = "Khách Hàng ";
            // 
            // 
            // 
            this.rbbKhachHang.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.rbbKhachHang.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnKhachHang
            // 
            this.btnKhachHang.Image = global::GUI.Properties.Resources.icon_bg_member;
            this.btnKhachHang.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnKhachHang.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.btnKhachHang.Name = "btnKhachHang";
            this.btnKhachHang.SubItemsExpandWidth = 14;
            this.btnKhachHang.Text = "<div align = \"center\" width = \"70\"></div>";
            this.btnKhachHang.Click += new System.EventHandler(this.btnKhachHang_Click);
            // 
            // ribbonBar2
            // 
            this.ribbonBar2.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar2.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar2.ContainerControlProcessDialogKey = true;
            this.ribbonBar2.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar2.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnNhanVien});
            this.ribbonBar2.Location = new System.Drawing.Point(179, 0);
            this.ribbonBar2.Name = "ribbonBar2";
            this.ribbonBar2.Size = new System.Drawing.Size(88, 95);
            this.ribbonBar2.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar2.TabIndex = 22;
            this.ribbonBar2.Text = "Nhân Viên ";
            // 
            // 
            // 
            this.ribbonBar2.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar2.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnNhanVien
            // 
            this.btnNhanVien.Image = global::GUI.Properties.Resources.NhanVien;
            this.btnNhanVien.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnNhanVien.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.btnNhanVien.Name = "btnNhanVien";
            this.btnNhanVien.SubItemsExpandWidth = 14;
            this.btnNhanVien.Text = "<div align = \"center\" width = \"70\"></div>";
            this.btnNhanVien.Click += new System.EventHandler(this.btnNhanVien_Click);
            // 
            // ribbonBar4
            // 
            this.ribbonBar4.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar4.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar4.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar4.ContainerControlProcessDialogKey = true;
            this.ribbonBar4.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar4.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnNhaCungCap});
            this.ribbonBar4.Location = new System.Drawing.Point(91, 0);
            this.ribbonBar4.Name = "ribbonBar4";
            this.ribbonBar4.Size = new System.Drawing.Size(88, 95);
            this.ribbonBar4.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar4.TabIndex = 29;
            this.ribbonBar4.Text = "Nhà Cung Cấp";
            // 
            // 
            // 
            this.ribbonBar4.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar4.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnNhaCungCap
            // 
            this.btnNhaCungCap.Image = global::GUI.Properties.Resources.House;
            this.btnNhaCungCap.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnNhaCungCap.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.btnNhaCungCap.Name = "btnNhaCungCap";
            this.btnNhaCungCap.SubItemsExpandWidth = 14;
            this.btnNhaCungCap.Text = "<div align = \"center\" width = \"70\"></div>";
            this.btnNhaCungCap.Click += new System.EventHandler(this.btnNhaCungCap_Click);
            // 
            // rbbNhaSanXuat
            // 
            this.rbbNhaSanXuat.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.rbbNhaSanXuat.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.rbbNhaSanXuat.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.rbbNhaSanXuat.ContainerControlProcessDialogKey = true;
            this.rbbNhaSanXuat.Dock = System.Windows.Forms.DockStyle.Left;
            this.rbbNhaSanXuat.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnNhaSanSuat});
            this.rbbNhaSanXuat.Location = new System.Drawing.Point(3, 0);
            this.rbbNhaSanXuat.Name = "rbbNhaSanXuat";
            this.rbbNhaSanXuat.Size = new System.Drawing.Size(88, 95);
            this.rbbNhaSanXuat.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.rbbNhaSanXuat.TabIndex = 28;
            this.rbbNhaSanXuat.Text = "Nhà Sản Xuất";
            // 
            // 
            // 
            this.rbbNhaSanXuat.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.rbbNhaSanXuat.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnNhaSanSuat
            // 
            this.btnNhaSanSuat.Image = global::GUI.Properties.Resources.Nhà_Sản_Xuất;
            this.btnNhaSanSuat.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnNhaSanSuat.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.btnNhaSanSuat.Name = "btnNhaSanSuat";
            this.btnNhaSanSuat.SubItemsExpandWidth = 14;
            this.btnNhaSanSuat.Text = "<div align = \"center\" width = \"70\"></div>";
            this.btnNhaSanSuat.Click += new System.EventHandler(this.btnNhaSanSuat_Click);
            // 
            // ribbonPanel3
            // 
            this.ribbonPanel3.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonPanel3.Controls.Add(this.rbbHoaDonBan);
            this.ribbonPanel3.Controls.Add(this.rbbHoaDonNhapHang);
            this.ribbonPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel3.Location = new System.Drawing.Point(0, 53);
            this.ribbonPanel3.Name = "ribbonPanel3";
            this.ribbonPanel3.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel3.Size = new System.Drawing.Size(790, 98);
            // 
            // 
            // 
            this.ribbonPanel3.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel3.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel3.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonPanel3.TabIndex = 3;
            this.ribbonPanel3.Visible = false;
            // 
            // rbbHoaDonBan
            // 
            this.rbbHoaDonBan.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.rbbHoaDonBan.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.rbbHoaDonBan.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.rbbHoaDonBan.ContainerControlProcessDialogKey = true;
            this.rbbHoaDonBan.Dock = System.Windows.Forms.DockStyle.Left;
            this.rbbHoaDonBan.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnHoaDonBan});
            this.rbbHoaDonBan.Location = new System.Drawing.Point(91, 0);
            this.rbbHoaDonBan.Name = "rbbHoaDonBan";
            this.rbbHoaDonBan.Size = new System.Drawing.Size(88, 95);
            this.rbbHoaDonBan.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.rbbHoaDonBan.TabIndex = 30;
            this.rbbHoaDonBan.Text = "Hóa Đơn Bán ";
            // 
            // 
            // 
            this.rbbHoaDonBan.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.rbbHoaDonBan.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnHoaDonBan
            // 
            this.btnHoaDonBan.Image = global::GUI.Properties.Resources.icon_contract;
            this.btnHoaDonBan.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnHoaDonBan.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.btnHoaDonBan.Name = "btnHoaDonBan";
            this.btnHoaDonBan.SubItemsExpandWidth = 14;
            this.btnHoaDonBan.Text = "<div align = \"center\" width = \"70\"></div>";
            this.btnHoaDonBan.Click += new System.EventHandler(this.btnHoaDonBan_Click);
            // 
            // rbbHoaDonNhapHang
            // 
            this.rbbHoaDonNhapHang.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.rbbHoaDonNhapHang.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.rbbHoaDonNhapHang.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.rbbHoaDonNhapHang.ContainerControlProcessDialogKey = true;
            this.rbbHoaDonNhapHang.Dock = System.Windows.Forms.DockStyle.Left;
            this.rbbHoaDonNhapHang.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnHoaDonNhap});
            this.rbbHoaDonNhapHang.Location = new System.Drawing.Point(3, 0);
            this.rbbHoaDonNhapHang.Name = "rbbHoaDonNhapHang";
            this.rbbHoaDonNhapHang.Size = new System.Drawing.Size(88, 95);
            this.rbbHoaDonNhapHang.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.rbbHoaDonNhapHang.TabIndex = 29;
            this.rbbHoaDonNhapHang.Text = "Hóa Đơn Nhập";
            // 
            // 
            // 
            this.rbbHoaDonNhapHang.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.rbbHoaDonNhapHang.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnHoaDonNhap
            // 
            this.btnHoaDonNhap.Image = global::GUI.Properties.Resources.invoice_manager_icon;
            this.btnHoaDonNhap.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnHoaDonNhap.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.btnHoaDonNhap.ImageSmall = global::GUI.Properties.Resources.NhaPhatTriển;
            this.btnHoaDonNhap.Name = "btnHoaDonNhap";
            this.btnHoaDonNhap.SubItemsExpandWidth = 14;
            this.btnHoaDonNhap.Text = "<div align = \"center\" width = \"70\"></div>";
            this.btnHoaDonNhap.Click += new System.EventHandler(this.btnHoaDonNhap_Click);
            // 
            // ribbonPanel4
            // 
            this.ribbonPanel4.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonPanel4.Controls.Add(this.ribbonBar5);
            this.ribbonPanel4.Controls.Add(this.ribbonBar6);
            this.ribbonPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel4.Location = new System.Drawing.Point(0, 53);
            this.ribbonPanel4.Name = "ribbonPanel4";
            this.ribbonPanel4.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel4.Size = new System.Drawing.Size(790, 98);
            // 
            // 
            // 
            this.ribbonPanel4.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel4.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel4.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonPanel4.TabIndex = 4;
            this.ribbonPanel4.Visible = false;
            // 
            // ribbonBar5
            // 
            this.ribbonBar5.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar5.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar5.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar5.ContainerControlProcessDialogKey = true;
            this.ribbonBar5.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar5.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnLienHe});
            this.ribbonBar5.Location = new System.Drawing.Point(91, 0);
            this.ribbonBar5.Name = "ribbonBar5";
            this.ribbonBar5.Size = new System.Drawing.Size(88, 95);
            this.ribbonBar5.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar5.TabIndex = 32;
            this.ribbonBar5.Text = "Liên Hệ ";
            // 
            // 
            // 
            this.ribbonBar5.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar5.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnLienHe
            // 
            this.btnLienHe.Image = global::GUI.Properties.Resources.iconDienThoai;
            this.btnLienHe.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnLienHe.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.btnLienHe.Name = "btnLienHe";
            this.btnLienHe.SubItemsExpandWidth = 14;
            this.btnLienHe.Text = "<div align = \"center\" width = \"70\"></div>";
            // 
            // ribbonBar6
            // 
            this.ribbonBar6.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar6.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar6.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar6.ContainerControlProcessDialogKey = true;
            this.ribbonBar6.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar6.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnHoiDap});
            this.ribbonBar6.Location = new System.Drawing.Point(3, 0);
            this.ribbonBar6.Name = "ribbonBar6";
            this.ribbonBar6.Size = new System.Drawing.Size(88, 95);
            this.ribbonBar6.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar6.TabIndex = 31;
            this.ribbonBar6.Text = "Hỏi Đáp";
            // 
            // 
            // 
            this.ribbonBar6.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar6.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnHoiDap
            // 
            this.btnHoiDap.Image = global::GUI.Properties.Resources.HoiDap1;
            this.btnHoiDap.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnHoiDap.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.btnHoiDap.Name = "btnHoiDap";
            this.btnHoiDap.SubItemsExpandWidth = 14;
            this.btnHoiDap.Text = "<div align = \"center\" width = \"70\"></div>";
            // 
            // ribbonPanel1
            // 
            this.ribbonPanel1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonPanel1.Controls.Add(this.rbbThoatHeThong);
            this.ribbonPanel1.Controls.Add(this.rbbDoiHinhNen);
            this.ribbonPanel1.Controls.Add(this.rbbNguoiDung);
            this.ribbonPanel1.Controls.Add(this.rbbPhamQuyen);
            this.ribbonPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel1.Location = new System.Drawing.Point(0, 53);
            this.ribbonPanel1.Name = "ribbonPanel1";
            this.ribbonPanel1.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel1.Size = new System.Drawing.Size(790, 98);
            // 
            // 
            // 
            this.ribbonPanel1.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel1.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel1.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonPanel1.TabIndex = 1;
            this.ribbonPanel1.Visible = false;
            // 
            // rbbThoatHeThong
            // 
            this.rbbThoatHeThong.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.rbbThoatHeThong.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.rbbThoatHeThong.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.rbbThoatHeThong.ContainerControlProcessDialogKey = true;
            this.rbbThoatHeThong.Dock = System.Windows.Forms.DockStyle.Left;
            this.rbbThoatHeThong.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnThoatHeThong});
            this.rbbThoatHeThong.Location = new System.Drawing.Point(267, 0);
            this.rbbThoatHeThong.Name = "rbbThoatHeThong";
            this.rbbThoatHeThong.Size = new System.Drawing.Size(88, 95);
            this.rbbThoatHeThong.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.rbbThoatHeThong.TabIndex = 10;
            this.rbbThoatHeThong.Text = "Thoát Hệ Thống ";
            // 
            // 
            // 
            this.rbbThoatHeThong.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.rbbThoatHeThong.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.rbbThoatHeThong.ItemClick += new System.EventHandler(this.rbbThoatHeThong_ItemClick);
            // 
            // btnThoatHeThong
            // 
            this.btnThoatHeThong.Image = global::GUI.Properties.Resources._128px_Crystal_Clear_action_exit_svg;
            this.btnThoatHeThong.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnThoatHeThong.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.btnThoatHeThong.Name = "btnThoatHeThong";
            this.btnThoatHeThong.SubItemsExpandWidth = 14;
            this.btnThoatHeThong.Text = "<div align = \"center\" width = \"70\"></div>";
            this.btnThoatHeThong.Click += new System.EventHandler(this.btnThoatHeThong_Click);
            // 
            // rbbDoiHinhNen
            // 
            this.rbbDoiHinhNen.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.rbbDoiHinhNen.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.rbbDoiHinhNen.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.rbbDoiHinhNen.ContainerControlProcessDialogKey = true;
            this.rbbDoiHinhNen.Dock = System.Windows.Forms.DockStyle.Left;
            this.rbbDoiHinhNen.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnDoiHinhNen});
            this.rbbDoiHinhNen.Location = new System.Drawing.Point(179, 0);
            this.rbbDoiHinhNen.Name = "rbbDoiHinhNen";
            this.rbbDoiHinhNen.Size = new System.Drawing.Size(88, 95);
            this.rbbDoiHinhNen.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.rbbDoiHinhNen.TabIndex = 9;
            this.rbbDoiHinhNen.Text = "Đối Hình Nền ";
            // 
            // 
            // 
            this.rbbDoiHinhNen.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.rbbDoiHinhNen.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnDoiHinhNen
            // 
            this.btnDoiHinhNen.Image = global::GUI.Properties.Resources.iPhoto;
            this.btnDoiHinhNen.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnDoiHinhNen.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.btnDoiHinhNen.Name = "btnDoiHinhNen";
            this.btnDoiHinhNen.SubItemsExpandWidth = 14;
            this.btnDoiHinhNen.Text = "<div align = \"center\" width = \"70\"></div>";
            // 
            // rbbNguoiDung
            // 
            this.rbbNguoiDung.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.rbbNguoiDung.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.rbbNguoiDung.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.rbbNguoiDung.ContainerControlProcessDialogKey = true;
            this.rbbNguoiDung.Dock = System.Windows.Forms.DockStyle.Left;
            this.rbbNguoiDung.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnNguoiDung});
            this.rbbNguoiDung.Location = new System.Drawing.Point(91, 0);
            this.rbbNguoiDung.Name = "rbbNguoiDung";
            this.rbbNguoiDung.Size = new System.Drawing.Size(88, 95);
            this.rbbNguoiDung.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.rbbNguoiDung.TabIndex = 8;
            this.rbbNguoiDung.Text = "Người Dùng  ";
            // 
            // 
            // 
            this.rbbNguoiDung.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.rbbNguoiDung.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnNguoiDung
            // 
            this.btnNguoiDung.Image = global::GUI.Properties.Resources.icon_bg_member;
            this.btnNguoiDung.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnNguoiDung.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.btnNguoiDung.Name = "btnNguoiDung";
            this.btnNguoiDung.SubItemsExpandWidth = 14;
            this.btnNguoiDung.Text = "<div align = \"center\" width = \"70\"></div>";
            this.btnNguoiDung.Click += new System.EventHandler(this.btnNguoiDung_Click);
            // 
            // rbbPhamQuyen
            // 
            this.rbbPhamQuyen.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.rbbPhamQuyen.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.rbbPhamQuyen.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.rbbPhamQuyen.ContainerControlProcessDialogKey = true;
            this.rbbPhamQuyen.Dock = System.Windows.Forms.DockStyle.Left;
            this.rbbPhamQuyen.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnPhanQuyen});
            this.rbbPhamQuyen.Location = new System.Drawing.Point(3, 0);
            this.rbbPhamQuyen.Name = "rbbPhamQuyen";
            this.rbbPhamQuyen.Size = new System.Drawing.Size(88, 95);
            this.rbbPhamQuyen.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.rbbPhamQuyen.TabIndex = 7;
            this.rbbPhamQuyen.Text = "Phân Quyền  ";
            // 
            // 
            // 
            this.rbbPhamQuyen.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.rbbPhamQuyen.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnPhanQuyen
            // 
            this.btnPhanQuyen.Image = global::GUI.Properties.Resources.mankey;
            this.btnPhanQuyen.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnPhanQuyen.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.btnPhanQuyen.Name = "btnPhanQuyen";
            this.btnPhanQuyen.SubItemsExpandWidth = 14;
            this.btnPhanQuyen.Text = "<div align = \"center\" width = \"70\"></div>";
            // 
            // ribbonPanel5
            // 
            this.ribbonPanel5.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonPanel5.Controls.Add(this.ribbonBar7);
            this.ribbonPanel5.Controls.Add(this.ribbonBar8);
            this.ribbonPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel5.Location = new System.Drawing.Point(0, 53);
            this.ribbonPanel5.Name = "ribbonPanel5";
            this.ribbonPanel5.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel5.Size = new System.Drawing.Size(790, 98);
            // 
            // 
            // 
            this.ribbonPanel5.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel5.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel5.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonPanel5.TabIndex = 5;
            this.ribbonPanel5.Visible = false;
            // 
            // ribbonBar7
            // 
            this.ribbonBar7.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar7.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar7.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar7.ContainerControlProcessDialogKey = true;
            this.ribbonBar7.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar7.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnThongTinCaNhan});
            this.ribbonBar7.Location = new System.Drawing.Point(91, 0);
            this.ribbonBar7.Name = "ribbonBar7";
            this.ribbonBar7.Size = new System.Drawing.Size(88, 95);
            this.ribbonBar7.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar7.TabIndex = 33;
            this.ribbonBar7.Text = "Thông Tin ";
            // 
            // 
            // 
            this.ribbonBar7.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar7.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnThongTinCaNhan
            // 
            this.btnThongTinCaNhan.Image = global::GUI.Properties.Resources.icon_contract;
            this.btnThongTinCaNhan.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnThongTinCaNhan.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.btnThongTinCaNhan.Name = "btnThongTinCaNhan";
            this.btnThongTinCaNhan.SubItemsExpandWidth = 14;
            this.btnThongTinCaNhan.Text = "<div align = \"center\" width = \"70\"></div>";
            this.btnThongTinCaNhan.Click += new System.EventHandler(this.btnThongTinCaNhan_Click);
            // 
            // ribbonBar8
            // 
            this.ribbonBar8.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar8.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar8.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar8.ContainerControlProcessDialogKey = true;
            this.ribbonBar8.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar8.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnDangXuat});
            this.ribbonBar8.Location = new System.Drawing.Point(3, 0);
            this.ribbonBar8.Name = "ribbonBar8";
            this.ribbonBar8.Size = new System.Drawing.Size(88, 95);
            this.ribbonBar8.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar8.TabIndex = 32;
            this.ribbonBar8.Text = "Đăng Xuất ";
            // 
            // 
            // 
            this.ribbonBar8.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar8.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnDangXuat
            // 
            this.btnDangXuat.Image = global::GUI.Properties.Resources.Thoát;
            this.btnDangXuat.ImageFixedSize = new System.Drawing.Size(70, 55);
            this.btnDangXuat.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.btnDangXuat.Name = "btnDangXuat";
            this.btnDangXuat.SubItemsExpandWidth = 14;
            this.btnDangXuat.Text = "<div align = \"center\" width = \"70\"></div>";
            this.btnDangXuat.Click += new System.EventHandler(this.btnDangXuat_Click);
            // 
            // ribbonPanel6
            // 
            this.ribbonPanel6.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonPanel6.Controls.Add(this.ribbonBar10);
            this.ribbonPanel6.Controls.Add(this.ribbonBar11);
            this.ribbonPanel6.Controls.Add(this.ribbonBar12);
            this.ribbonPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel6.Location = new System.Drawing.Point(0, 0);
            this.ribbonPanel6.Name = "ribbonPanel6";
            this.ribbonPanel6.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel6.Size = new System.Drawing.Size(790, 151);
            // 
            // 
            // 
            this.ribbonPanel6.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel6.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel6.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonPanel6.TabIndex = 6;
            this.ribbonPanel6.Visible = false;
            // 
            // ribbonBar10
            // 
            this.ribbonBar10.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar10.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar10.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar10.ContainerControlProcessDialogKey = true;
            this.ribbonBar10.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar10.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnDoiTac});
            this.ribbonBar10.Location = new System.Drawing.Point(179, 0);
            this.ribbonBar10.Name = "ribbonBar10";
            this.ribbonBar10.Size = new System.Drawing.Size(88, 148);
            this.ribbonBar10.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar10.TabIndex = 33;
            this.ribbonBar10.Text = "Đối Tác ";
            // 
            // 
            // 
            this.ribbonBar10.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar10.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnDoiTac
            // 
            this.btnDoiTac.Image = global::GUI.Properties.Resources.doi_tac;
            this.btnDoiTac.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnDoiTac.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.btnDoiTac.Name = "btnDoiTac";
            this.btnDoiTac.SubItemsExpandWidth = 14;
            this.btnDoiTac.Text = "<div align = \"center\" width = \"70\"></div>";
            // 
            // ribbonBar11
            // 
            this.ribbonBar11.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar11.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar11.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar11.ContainerControlProcessDialogKey = true;
            this.ribbonBar11.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar11.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnNhaPhatTrien});
            this.ribbonBar11.Location = new System.Drawing.Point(91, 0);
            this.ribbonBar11.Name = "ribbonBar11";
            this.ribbonBar11.Size = new System.Drawing.Size(88, 148);
            this.ribbonBar11.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar11.TabIndex = 32;
            this.ribbonBar11.Text = "Nhà Phát Triển ";
            // 
            // 
            // 
            this.ribbonBar11.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar11.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnNhaPhatTrien
            // 
            this.btnNhaPhatTrien.Image = global::GUI.Properties.Resources.NhaPhatTriển;
            this.btnNhaPhatTrien.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnNhaPhatTrien.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.btnNhaPhatTrien.Name = "btnNhaPhatTrien";
            this.btnNhaPhatTrien.SubItemsExpandWidth = 14;
            this.btnNhaPhatTrien.Text = "<div align = \"center\" width = \"70\"></div>";
            // 
            // ribbonBar12
            // 
            this.ribbonBar12.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar12.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar12.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar12.ContainerControlProcessDialogKey = true;
            this.ribbonBar12.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar12.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnThongtinNPT});
            this.ribbonBar12.Location = new System.Drawing.Point(3, 0);
            this.ribbonBar12.Name = "ribbonBar12";
            this.ribbonBar12.Size = new System.Drawing.Size(88, 148);
            this.ribbonBar12.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar12.TabIndex = 31;
            this.ribbonBar12.Text = "Thông Tin ";
            // 
            // 
            // 
            this.ribbonBar12.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar12.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnThongtinNPT
            // 
            this.btnThongtinNPT.Image = global::GUI.Properties.Resources.IconGioiThieu;
            this.btnThongtinNPT.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnThongtinNPT.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.btnThongtinNPT.Name = "btnThongtinNPT";
            this.btnThongtinNPT.SubItemsExpandWidth = 14;
            this.btnThongtinNPT.Text = "<div align = \"center\" width = \"70\"></div>";
            // 
            // ribbonTabItem1
            // 
            this.ribbonTabItem1.Name = "ribbonTabItem1";
            this.ribbonTabItem1.Panel = this.ribbonPanel1;
            this.ribbonTabItem1.Text = "Hệ Thống ";
            this.ribbonTabItem1.Click += new System.EventHandler(this.ribbonTabItem1_Click);
            // 
            // ribbonTabItem2
            // 
            this.ribbonTabItem2.Checked = true;
            this.ribbonTabItem2.Name = "ribbonTabItem2";
            this.ribbonTabItem2.Panel = this.ribbonPanel2;
            this.ribbonTabItem2.Text = "Quản Lý ";
            // 
            // ribbonTabItem3
            // 
            this.ribbonTabItem3.Name = "ribbonTabItem3";
            this.ribbonTabItem3.Panel = this.ribbonPanel3;
            this.ribbonTabItem3.Text = "Thống Kê ";
            // 
            // ribbonTabItem4
            // 
            this.ribbonTabItem4.Name = "ribbonTabItem4";
            this.ribbonTabItem4.Panel = this.ribbonPanel4;
            this.ribbonTabItem4.Text = "Hướng Dẫn ";
            // 
            // ribbonTabItem5
            // 
            this.ribbonTabItem5.Name = "ribbonTabItem5";
            this.ribbonTabItem5.Panel = this.ribbonPanel5;
            this.ribbonTabItem5.Text = "Cá Nhân ";
            // 
            // ribbonTabItem6
            // 
            this.ribbonTabItem6.Name = "ribbonTabItem6";
            this.ribbonTabItem6.Panel = this.ribbonPanel6;
            this.ribbonTabItem6.Text = "Giới Thiệu ";
            // 
            // textBoxItem1
            // 
            this.textBoxItem1.Name = "textBoxItem1";
            this.textBoxItem1.Text = "Xin Chào : Phan Đình Kiên ";
            this.textBoxItem1.WatermarkColor = System.Drawing.SystemColors.GrayText;
            // 
            // styleManager1
            // 
            this.styleManager1.ManagerStyle = DevComponents.DotNetBar.eStyle.Office2010Blue;
            this.styleManager1.MetroColorParameters = new DevComponents.DotNetBar.Metro.ColorTables.MetroColorGeneratorParameters(System.Drawing.Color.White, System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(87)))), ((int)(((byte)(154))))));
            // 
            // TabHeThong
            // 
            this.TabHeThong.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(221)))), ((int)(((byte)(238)))));
            this.TabHeThong.CanReorderTabs = true;
            this.TabHeThong.CloseButtonOnTabsAlwaysDisplayed = false;
            this.TabHeThong.CloseButtonOnTabsVisible = true;
            this.TabHeThong.CloseButtonPosition = DevComponents.DotNetBar.eTabCloseButtonPosition.Right;
            this.TabHeThong.Controls.Add(this.tabControlPanel1);
            this.TabHeThong.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TabHeThong.Location = new System.Drawing.Point(5, 155);
            this.TabHeThong.Name = "TabHeThong";
            this.TabHeThong.SelectedTabFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.TabHeThong.SelectedTabIndex = 0;
            this.TabHeThong.Size = new System.Drawing.Size(790, 260);
            this.TabHeThong.TabIndex = 2;
            this.TabHeThong.TabLayoutType = DevComponents.DotNetBar.eTabLayoutType.FixedWithNavigationBox;
            this.TabHeThong.Tabs.Add(this.TabGioiThieu);
            this.TabHeThong.Text = "tabControl1";
            // 
            // tabControlPanel1
            // 
            this.tabControlPanel1.Controls.Add(this.pictureBox1);
            this.tabControlPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel1.Location = new System.Drawing.Point(0, 26);
            this.tabControlPanel1.Name = "tabControlPanel1";
            this.tabControlPanel1.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel1.Size = new System.Drawing.Size(790, 234);
            this.tabControlPanel1.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(179)))), ((int)(((byte)(231)))));
            this.tabControlPanel1.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(237)))), ((int)(((byte)(254)))));
            this.tabControlPanel1.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel1.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(97)))), ((int)(((byte)(156)))));
            this.tabControlPanel1.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right) 
            | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel1.Style.GradientAngle = 90;
            this.tabControlPanel1.TabIndex = 1;
            this.tabControlPanel1.TabItem = this.TabGioiThieu;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(788, 232);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // TabGioiThieu
            // 
            this.TabGioiThieu.AttachedControl = this.tabControlPanel1;
            this.TabGioiThieu.CloseButtonVisible = false;
            this.TabGioiThieu.Name = "TabGioiThieu";
            this.TabGioiThieu.Text = "Giới Thiệu ";
            // 
            // rbTabQuanLy
            // 
            this.rbTabQuanLy.Checked = true;
            this.rbTabQuanLy.Name = "rbTabQuanLy";
            this.rbTabQuanLy.Text = "Quản Lý ";
            // 
            // ribbonTabItem7
            // 
            this.ribbonTabItem7.Checked = true;
            this.ribbonTabItem7.Name = "ribbonTabItem7";
            this.ribbonTabItem7.Panel = this.ribbonPanel3;
            this.ribbonTabItem7.Text = "Thống Kê ";
            // 
            // ribbonTabItem8
            // 
            this.ribbonTabItem8.Checked = true;
            this.ribbonTabItem8.Name = "ribbonTabItem8";
            this.ribbonTabItem8.Panel = this.ribbonPanel3;
            this.ribbonTabItem8.Text = "Thống Kê ";
            // 
            // ribbonTabItem9
            // 
            this.ribbonTabItem9.Checked = true;
            this.ribbonTabItem9.Name = "ribbonTabItem9";
            this.ribbonTabItem9.Panel = this.ribbonPanel3;
            this.ribbonTabItem9.Text = "Thống Kê ";
            // 
            // MenuStripHeThong
            // 
            this.MenuStripHeThong.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItemDongTrang,
            this.MenuItemDongTrangKhac,
            this.MenuItemDongTatCa,
            this.toolStripMenuItem2,
            this.MenuItemThoat});
            this.MenuStripHeThong.Name = "MenuStripHeThong";
            this.MenuStripHeThong.Size = new System.Drawing.Size(177, 98);
            // 
            // MenuItemDongTrang
            // 
            this.MenuItemDongTrang.Image = global::GUI.Properties.Resources.close_blue;
            this.MenuItemDongTrang.Name = "MenuItemDongTrang";
            this.MenuItemDongTrang.Size = new System.Drawing.Size(176, 22);
            this.MenuItemDongTrang.Text = "Đóng Trang ";
            // 
            // MenuItemDongTrangKhac
            // 
            this.MenuItemDongTrangKhac.Image = global::GUI.Properties.Resources.Actions_window_close_icon;
            this.MenuItemDongTrangKhac.Name = "MenuItemDongTrangKhac";
            this.MenuItemDongTrangKhac.Size = new System.Drawing.Size(176, 22);
            this.MenuItemDongTrangKhac.Text = "Đóng Trang Khác";
            // 
            // MenuItemDongTatCa
            // 
            this.MenuItemDongTatCa.Image = global::GUI.Properties.Resources.Delete;
            this.MenuItemDongTatCa.Name = "MenuItemDongTatCa";
            this.MenuItemDongTatCa.Size = new System.Drawing.Size(176, 22);
            this.MenuItemDongTatCa.Text = "Đóng Tất Cả Trang ";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(173, 6);
            // 
            // MenuItemThoat
            // 
            this.MenuItemThoat.Image = global::GUI.Properties.Resources._128px_Crystal_Clear_action_exit1;
            this.MenuItemThoat.Name = "MenuItemThoat";
            this.MenuItemThoat.Size = new System.Drawing.Size(176, 22);
            this.MenuItemThoat.Text = "Thoát ";
            // 
            // frmQuanLyBanHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 417);
            this.Controls.Add(this.TabHeThong);
            this.Controls.Add(this.ribbonControl1);
            this.Name = "frmQuanLyBanHang";
            this.Text = "frmQuanLyBanHang";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmQuanLyBanHang_FormClosed);
            this.Load += new System.EventHandler(this.frmQuanLyBanHang_Load);
            this.ribbonControl1.ResumeLayout(false);
            this.ribbonControl1.PerformLayout();
            this.ribbonPanel2.ResumeLayout(false);
            this.ribbonPanel3.ResumeLayout(false);
            this.ribbonPanel4.ResumeLayout(false);
            this.ribbonPanel1.ResumeLayout(false);
            this.ribbonPanel5.ResumeLayout(false);
            this.ribbonPanel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.TabHeThong)).EndInit();
            this.TabHeThong.ResumeLayout(false);
            this.tabControlPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.MenuStripHeThong.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.RibbonControl ribbonControl1;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel1;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel2;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItem1;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItem2;
        private DevComponents.DotNetBar.StyleManager styleManager1;
        private DevComponents.DotNetBar.RibbonBar rbbThoatHeThong;
        private DevComponents.DotNetBar.ButtonItem btnThoatHeThong;
        private DevComponents.DotNetBar.RibbonBar rbbDoiHinhNen;
        private DevComponents.DotNetBar.ButtonItem btnDoiHinhNen;
        private DevComponents.DotNetBar.RibbonBar rbbNguoiDung;
        private DevComponents.DotNetBar.ButtonItem btnNguoiDung;
        private DevComponents.DotNetBar.RibbonBar rbbPhamQuyen;
        private DevComponents.DotNetBar.ButtonItem btnPhanQuyen;
        private DevComponents.DotNetBar.TabControl TabHeThong;
        private DevComponents.DotNetBar.TabControlPanel tabControlPanel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private DevComponents.DotNetBar.TabItem TabGioiThieu;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel3;
        private DevComponents.DotNetBar.RibbonBar rbbHoaDonBan;
        private DevComponents.DotNetBar.ButtonItem btnHoaDonBan;
        private DevComponents.DotNetBar.RibbonBar rbbHoaDonNhapHang;
        private DevComponents.DotNetBar.ButtonItem btnHoaDonNhap;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel6;
        private DevComponents.DotNetBar.RibbonBar ribbonBar10;
        private DevComponents.DotNetBar.ButtonItem btnDoiTac;
        private DevComponents.DotNetBar.RibbonBar ribbonBar11;
        private DevComponents.DotNetBar.ButtonItem btnNhaPhatTrien;
        private DevComponents.DotNetBar.RibbonBar ribbonBar12;
        private DevComponents.DotNetBar.ButtonItem btnThongtinNPT;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel5;
        private DevComponents.DotNetBar.RibbonBar ribbonBar7;
        private DevComponents.DotNetBar.ButtonItem btnThongTinCaNhan;
        private DevComponents.DotNetBar.RibbonBar ribbonBar8;
        private DevComponents.DotNetBar.ButtonItem btnDangXuat;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel4;
        private DevComponents.DotNetBar.RibbonBar ribbonBar5;
        private DevComponents.DotNetBar.ButtonItem btnLienHe;
        private DevComponents.DotNetBar.RibbonBar ribbonBar6;
        private DevComponents.DotNetBar.ButtonItem btnHoiDap;
        private DevComponents.DotNetBar.RibbonBar rbbKhoHang;
        private DevComponents.DotNetBar.ButtonItem btbKhoHang;
        private DevComponents.DotNetBar.RibbonBar rbbLoaiSanPham;
        private DevComponents.DotNetBar.ButtonItem btnLoaiSanPham;
        private DevComponents.DotNetBar.RibbonBar rbbSanPham;
        private DevComponents.DotNetBar.ButtonItem btnSanPham;
        private DevComponents.DotNetBar.RibbonBar rbbLoaiKhachHang;
        private DevComponents.DotNetBar.ButtonItem btnloaiKhachHang;
        private DevComponents.DotNetBar.RibbonBar rbbKhachHang;
        private DevComponents.DotNetBar.ButtonItem btnKhachHang;
        private DevComponents.DotNetBar.RibbonBar ribbonBar2;
        private DevComponents.DotNetBar.ButtonItem btnNhanVien;
        private DevComponents.DotNetBar.RibbonBar ribbonBar4;
        private DevComponents.DotNetBar.ButtonItem btnNhaCungCap;
        private DevComponents.DotNetBar.RibbonBar rbbNhaSanXuat;
        private DevComponents.DotNetBar.ButtonItem btnNhaSanSuat;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItem3;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItem4;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItem5;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItem6;
        private DevComponents.DotNetBar.RibbonTabItem rbTabQuanLy;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItem7;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItem8;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItem9;
        private System.Windows.Forms.ContextMenuStrip MenuStripHeThong;
        private System.Windows.Forms.ToolStripMenuItem MenuItemDongTrang;
        private System.Windows.Forms.ToolStripMenuItem MenuItemDongTrangKhac;
        private System.Windows.Forms.ToolStripMenuItem MenuItemDongTatCa;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem MenuItemThoat;
        private DevComponents.DotNetBar.TextBoxItem textBoxItem1;
    }
}