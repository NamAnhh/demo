﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class CT_PhieuXuat
    {
        public string MaSanPham
        {
            get;
            set; 
        }

        public string TenSanPham
        {
            get;
            set;
        }

        public string MaPhieuXuat
        {
            get;
            set;
        }

        public double TongTien
        {
            get;
            set; 
        }

        public double DonGia
        {
            get;
            set; 
        }
        public string GhiChu
        {
            get;
            set; 
        }
        public int SoLuong
        {
            get;
            set; 
        }
    }
}
