﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class PhieuNhap
    {
        public  string MaPhieuNhap
        {
            get;
            set; 
        }

        public string NhanVien
        {
            get;
            set; 
        }

        public string MaNhanVien
        {
            get;
            set; 
        }

        public string MaNhaCungCap

        {
            get;
            set; 
        }

        public string NhaCungCap
        {
            get;
            set; 
        }

        public DateTime NgayNhap
        {
            get;
            set; 
        }
        public string KhoHang
        {
            get;
            set; 
        }
    }
}
