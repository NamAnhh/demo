﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class TaiKhoan
    {
        public string TenTaiKhoan
        {
            get;
            set; 
        }
        public string MatKhau
        {
            get;
            set;
        }
        public string TenDayDu
        {
            get;
            set; 
        }
        public string GioiTinh
        {
            get;
            set;
        }
        public string DienThoai
        {
            get;
            set;
        }

        public bool HienThi
        {
            get;
            set;
        }

    }
}
